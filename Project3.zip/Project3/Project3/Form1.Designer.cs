﻿namespace Project3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCurrentDate = new System.Windows.Forms.Label();
            this.lblKincadeCatering = new System.Windows.Forms.Label();
            this.lblNumOfGuests = new System.Windows.Forms.Label();
            this.txtNumOfGuests = new System.Windows.Forms.TextBox();
            this.grbMenuChoice = new System.Windows.Forms.GroupBox();
            this.rdoPasta = new System.Windows.Forms.RadioButton();
            this.rdoChicken = new System.Windows.Forms.RadioButton();
            this.rdoSteak = new System.Windows.Forms.RadioButton();
            this.grbSauces = new System.Windows.Forms.GroupBox();
            this.cmbSauces = new System.Windows.Forms.ComboBox();
            this.grbSides = new System.Windows.Forms.GroupBox();
            this.cmbSides = new System.Windows.Forms.ComboBox();
            this.grbBarSelection = new System.Windows.Forms.GroupBox();
            this.chbWineWDinner = new System.Windows.Forms.CheckBox();
            this.chbOpenBar = new System.Windows.Forms.CheckBox();
            this.lblAmountDue = new System.Windows.Forms.Label();
            this.txtAmountDue = new System.Windows.Forms.TextBox();
            this.btnCalc = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnSummary = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblDateText = new System.Windows.Forms.Label();
            this.grbMenuChoice.SuspendLayout();
            this.grbSauces.SuspendLayout();
            this.grbSides.SuspendLayout();
            this.grbBarSelection.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblCurrentDate
            // 
            this.lblCurrentDate.AutoSize = true;
            this.lblCurrentDate.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurrentDate.Location = new System.Drawing.Point(24, 17);
            this.lblCurrentDate.Name = "lblCurrentDate";
            this.lblCurrentDate.Size = new System.Drawing.Size(120, 20);
            this.lblCurrentDate.TabIndex = 0;
            this.lblCurrentDate.Text = "Current Date:";
            // 
            // lblKincadeCatering
            // 
            this.lblKincadeCatering.AutoSize = true;
            this.lblKincadeCatering.Font = new System.Drawing.Font("Broadway", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKincadeCatering.Location = new System.Drawing.Point(335, 83);
            this.lblKincadeCatering.Name = "lblKincadeCatering";
            this.lblKincadeCatering.Size = new System.Drawing.Size(440, 46);
            this.lblKincadeCatering.TabIndex = 2;
            this.lblKincadeCatering.Text = "Kincade\'s Catering";
            // 
            // lblNumOfGuests
            // 
            this.lblNumOfGuests.AutoSize = true;
            this.lblNumOfGuests.Font = new System.Drawing.Font("Arial Rounded MT Bold", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNumOfGuests.Location = new System.Drawing.Point(41, 83);
            this.lblNumOfGuests.Name = "lblNumOfGuests";
            this.lblNumOfGuests.Size = new System.Drawing.Size(135, 16);
            this.lblNumOfGuests.TabIndex = 3;
            this.lblNumOfGuests.Text = "Number of Guests:";
            // 
            // txtNumOfGuests
            // 
            this.txtNumOfGuests.Location = new System.Drawing.Point(44, 119);
            this.txtNumOfGuests.Name = "txtNumOfGuests";
            this.txtNumOfGuests.Size = new System.Drawing.Size(132, 22);
            this.txtNumOfGuests.TabIndex = 4;
            // 
            // grbMenuChoice
            // 
            this.grbMenuChoice.Controls.Add(this.rdoPasta);
            this.grbMenuChoice.Controls.Add(this.rdoChicken);
            this.grbMenuChoice.Controls.Add(this.rdoSteak);
            this.grbMenuChoice.Font = new System.Drawing.Font("Arial Rounded MT Bold", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbMenuChoice.Location = new System.Drawing.Point(44, 179);
            this.grbMenuChoice.Name = "grbMenuChoice";
            this.grbMenuChoice.Size = new System.Drawing.Size(200, 176);
            this.grbMenuChoice.TabIndex = 5;
            this.grbMenuChoice.TabStop = false;
            this.grbMenuChoice.Text = "Menu Choice";
            // 
            // rdoPasta
            // 
            this.rdoPasta.AutoSize = true;
            this.rdoPasta.Location = new System.Drawing.Point(6, 119);
            this.rdoPasta.Name = "rdoPasta";
            this.rdoPasta.Size = new System.Drawing.Size(67, 20);
            this.rdoPasta.TabIndex = 15;
            this.rdoPasta.TabStop = true;
            this.rdoPasta.Text = "Pasta";
            this.rdoPasta.UseVisualStyleBackColor = true;
            // 
            // rdoChicken
            // 
            this.rdoChicken.AutoSize = true;
            this.rdoChicken.Location = new System.Drawing.Point(7, 77);
            this.rdoChicken.Name = "rdoChicken";
            this.rdoChicken.Size = new System.Drawing.Size(83, 20);
            this.rdoChicken.TabIndex = 14;
            this.rdoChicken.TabStop = true;
            this.rdoChicken.Text = "Chicken";
            this.rdoChicken.UseVisualStyleBackColor = true;
            // 
            // rdoSteak
            // 
            this.rdoSteak.AutoSize = true;
            this.rdoSteak.Location = new System.Drawing.Point(7, 37);
            this.rdoSteak.Name = "rdoSteak";
            this.rdoSteak.Size = new System.Drawing.Size(67, 20);
            this.rdoSteak.TabIndex = 0;
            this.rdoSteak.TabStop = true;
            this.rdoSteak.Text = "Steak";
            this.rdoSteak.UseVisualStyleBackColor = true;
            // 
            // grbSauces
            // 
            this.grbSauces.Controls.Add(this.cmbSauces);
            this.grbSauces.Font = new System.Drawing.Font("Arial Rounded MT Bold", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbSauces.Location = new System.Drawing.Point(305, 179);
            this.grbSauces.Name = "grbSauces";
            this.grbSauces.Size = new System.Drawing.Size(200, 85);
            this.grbSauces.TabIndex = 6;
            this.grbSauces.TabStop = false;
            this.grbSauces.Text = "Sauces";
            // 
            // cmbSauces
            // 
            this.cmbSauces.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSauces.FormattingEnabled = true;
            this.cmbSauces.Items.AddRange(new object[] {
            "Drawn Butter",
            "Aioli",
            "Garlic Sauce",
            "Hollandaise",
            "Remoulade"});
            this.cmbSauces.Location = new System.Drawing.Point(7, 34);
            this.cmbSauces.Name = "cmbSauces";
            this.cmbSauces.Size = new System.Drawing.Size(174, 23);
            this.cmbSauces.TabIndex = 0;
            // 
            // grbSides
            // 
            this.grbSides.Controls.Add(this.cmbSides);
            this.grbSides.Font = new System.Drawing.Font("Arial Rounded MT Bold", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbSides.Location = new System.Drawing.Point(305, 271);
            this.grbSides.Name = "grbSides";
            this.grbSides.Size = new System.Drawing.Size(200, 84);
            this.grbSides.TabIndex = 6;
            this.grbSides.TabStop = false;
            this.grbSides.Text = "Sides";
            // 
            // cmbSides
            // 
            this.cmbSides.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSides.FormattingEnabled = true;
            this.cmbSides.Items.AddRange(new object[] {
            "Brussels Sprouts",
            "Butternut Squash",
            "Macaroni Salad",
            "Roasted Broccoli"});
            this.cmbSides.Location = new System.Drawing.Point(6, 39);
            this.cmbSides.Name = "cmbSides";
            this.cmbSides.Size = new System.Drawing.Size(175, 23);
            this.cmbSides.TabIndex = 14;
            // 
            // grbBarSelection
            // 
            this.grbBarSelection.Controls.Add(this.chbWineWDinner);
            this.grbBarSelection.Controls.Add(this.chbOpenBar);
            this.grbBarSelection.Font = new System.Drawing.Font("Arial Rounded MT Bold", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grbBarSelection.Location = new System.Drawing.Point(537, 179);
            this.grbBarSelection.Name = "grbBarSelection";
            this.grbBarSelection.Size = new System.Drawing.Size(200, 176);
            this.grbBarSelection.TabIndex = 7;
            this.grbBarSelection.TabStop = false;
            this.grbBarSelection.Text = "Bar Selection";
            // 
            // chbWineWDinner
            // 
            this.chbWineWDinner.AutoSize = true;
            this.chbWineWDinner.Location = new System.Drawing.Point(18, 92);
            this.chbWineWDinner.Name = "chbWineWDinner";
            this.chbWineWDinner.Size = new System.Drawing.Size(143, 20);
            this.chbWineWDinner.TabIndex = 1;
            this.chbWineWDinner.Text = "Wine with Dinner";
            this.chbWineWDinner.UseVisualStyleBackColor = true;
            // 
            // chbOpenBar
            // 
            this.chbOpenBar.AutoSize = true;
            this.chbOpenBar.Location = new System.Drawing.Point(18, 37);
            this.chbOpenBar.Name = "chbOpenBar";
            this.chbOpenBar.Size = new System.Drawing.Size(94, 20);
            this.chbOpenBar.TabIndex = 0;
            this.chbOpenBar.Text = "Open Bar";
            this.chbOpenBar.UseVisualStyleBackColor = true;
            // 
            // lblAmountDue
            // 
            this.lblAmountDue.AutoSize = true;
            this.lblAmountDue.Font = new System.Drawing.Font("Arial Rounded MT Bold", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAmountDue.Location = new System.Drawing.Point(209, 373);
            this.lblAmountDue.Name = "lblAmountDue";
            this.lblAmountDue.Size = new System.Drawing.Size(93, 16);
            this.lblAmountDue.TabIndex = 8;
            this.lblAmountDue.Text = "Amount Due:";
            // 
            // txtAmountDue
            // 
            this.txtAmountDue.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAmountDue.Location = new System.Drawing.Point(312, 369);
            this.txtAmountDue.Name = "txtAmountDue";
            this.txtAmountDue.ReadOnly = true;
            this.txtAmountDue.Size = new System.Drawing.Size(121, 27);
            this.txtAmountDue.TabIndex = 9;
            // 
            // btnCalc
            // 
            this.btnCalc.Font = new System.Drawing.Font("Arial Rounded MT Bold", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalc.Location = new System.Drawing.Point(343, 408);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(90, 30);
            this.btnCalc.TabIndex = 10;
            this.btnCalc.Text = "Calculate";
            this.btnCalc.UseVisualStyleBackColor = true;
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // btnClear
            // 
            this.btnClear.Font = new System.Drawing.Font("Arial Rounded MT Bold", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.Location = new System.Drawing.Point(459, 408);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(80, 30);
            this.btnClear.TabIndex = 11;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnSummary
            // 
            this.btnSummary.Font = new System.Drawing.Font("Arial Rounded MT Bold", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSummary.Location = new System.Drawing.Point(565, 408);
            this.btnSummary.Name = "btnSummary";
            this.btnSummary.Size = new System.Drawing.Size(81, 30);
            this.btnSummary.TabIndex = 12;
            this.btnSummary.Text = "Summary";
            this.btnSummary.UseVisualStyleBackColor = true;
            this.btnSummary.Click += new System.EventHandler(this.btnSummary_Click);
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Arial Rounded MT Bold", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(674, 408);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(89, 30);
            this.btnExit.TabIndex = 13;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblDateText
            // 
            this.lblDateText.AutoSize = true;
            this.lblDateText.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDateText.Location = new System.Drawing.Point(150, 17);
            this.lblDateText.Name = "lblDateText";
            this.lblDateText.Size = new System.Drawing.Size(0, 20);
            this.lblDateText.TabIndex = 14;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblDateText);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnSummary);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnCalc);
            this.Controls.Add(this.txtAmountDue);
            this.Controls.Add(this.lblAmountDue);
            this.Controls.Add(this.grbBarSelection);
            this.Controls.Add(this.grbSides);
            this.Controls.Add(this.grbSauces);
            this.Controls.Add(this.grbMenuChoice);
            this.Controls.Add(this.txtNumOfGuests);
            this.Controls.Add(this.lblNumOfGuests);
            this.Controls.Add(this.lblKincadeCatering);
            this.Controls.Add(this.lblCurrentDate);
            this.Name = "Form1";
            this.Text = "Kincade\'s Catering";
            this.grbMenuChoice.ResumeLayout(false);
            this.grbMenuChoice.PerformLayout();
            this.grbSauces.ResumeLayout(false);
            this.grbSides.ResumeLayout(false);
            this.grbBarSelection.ResumeLayout(false);
            this.grbBarSelection.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCurrentDate;
        private System.Windows.Forms.Label lblKincadeCatering;
        private System.Windows.Forms.Label lblNumOfGuests;
        private System.Windows.Forms.TextBox txtNumOfGuests;
        private System.Windows.Forms.GroupBox grbMenuChoice;
        private System.Windows.Forms.GroupBox grbSauces;
        private System.Windows.Forms.GroupBox grbSides;
        private System.Windows.Forms.GroupBox grbBarSelection;
        private System.Windows.Forms.Label lblAmountDue;
        private System.Windows.Forms.TextBox txtAmountDue;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnSummary;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.RadioButton rdoPasta;
        private System.Windows.Forms.RadioButton rdoChicken;
        private System.Windows.Forms.RadioButton rdoSteak;
        private System.Windows.Forms.ComboBox cmbSauces;
        private System.Windows.Forms.ComboBox cmbSides;
        private System.Windows.Forms.CheckBox chbWineWDinner;
        private System.Windows.Forms.CheckBox chbOpenBar;
        private System.Windows.Forms.Label lblDateText;
    }
}


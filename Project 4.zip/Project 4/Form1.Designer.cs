﻿namespace Project_4
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbxMenuStrip = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mainMenuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gradesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.pnlStudent = new System.Windows.Forms.Panel();
            this.grbStudent = new System.Windows.Forms.GroupBox();
            this.btnAddStudent = new System.Windows.Forms.Button();
            this.cboMajor = new System.Windows.Forms.ComboBox();
            this.cboCollege = new System.Windows.Forms.ComboBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblCollege = new System.Windows.Forms.Label();
            this.lblMajor = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblStudents = new System.Windows.Forms.Label();
            this.pnlGrades = new System.Windows.Forms.Panel();
            this.lblGrades = new System.Windows.Forms.Label();
            this.dgbStudents = new System.Windows.Forms.DataGridView();
            this.grbAddGrades = new System.Windows.Forms.GroupBox();
            this.cboStudent = new System.Windows.Forms.ComboBox();
            this.cboTerm = new System.Windows.Forms.ComboBox();
            this.cboGrade = new System.Windows.Forms.ComboBox();
            this.cboCourse = new System.Windows.Forms.ComboBox();
            this.btnAddGrade = new System.Windows.Forms.Button();
            this.lblStudent = new System.Windows.Forms.Label();
            this.lblGrade = new System.Windows.Forms.Label();
            this.lblTerm = new System.Windows.Forms.Label();
            this.lblCourse = new System.Windows.Forms.Label();
            this.dgbGrades = new System.Windows.Forms.DataGridView();
            this.tbxMenuStrip.SuspendLayout();
            this.pnlStudent.SuspendLayout();
            this.grbStudent.SuspendLayout();
            this.pnlGrades.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgbStudents)).BeginInit();
            this.grbAddGrades.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgbGrades)).BeginInit();
            this.SuspendLayout();
            // 
            // tbxMenuStrip
            // 
            this.tbxMenuStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.tbxMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.studentsToolStripMenuItem,
            this.gradesToolStripMenuItem});
            this.tbxMenuStrip.Location = new System.Drawing.Point(0, 0);
            this.tbxMenuStrip.Name = "tbxMenuStrip";
            this.tbxMenuStrip.Size = new System.Drawing.Size(1272, 28);
            this.tbxMenuStrip.TabIndex = 0;
            this.tbxMenuStrip.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mainMenuToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(46, 24);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // mainMenuToolStripMenuItem
            // 
            this.mainMenuToolStripMenuItem.Name = "mainMenuToolStripMenuItem";
            this.mainMenuToolStripMenuItem.Size = new System.Drawing.Size(166, 26);
            this.mainMenuToolStripMenuItem.Text = "Main Menu";
            this.mainMenuToolStripMenuItem.Click += new System.EventHandler(this.mainMenuToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(166, 26);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // studentsToolStripMenuItem
            // 
            this.studentsToolStripMenuItem.Name = "studentsToolStripMenuItem";
            this.studentsToolStripMenuItem.Size = new System.Drawing.Size(80, 24);
            this.studentsToolStripMenuItem.Text = "Students";
            this.studentsToolStripMenuItem.Click += new System.EventHandler(this.studentsToolStripMenuItem_Click);
            // 
            // gradesToolStripMenuItem
            // 
            this.gradesToolStripMenuItem.Name = "gradesToolStripMenuItem";
            this.gradesToolStripMenuItem.Size = new System.Drawing.Size(69, 24);
            this.gradesToolStripMenuItem.Text = "Grades";
            this.gradesToolStripMenuItem.Click += new System.EventHandler(this.gradesToolStripMenuItem_Click);
            // 
            // pnlMain
            // 
            this.pnlMain.BackgroundImage = global::Project_4.Properties.Resources.OldMain;
            this.pnlMain.Location = new System.Drawing.Point(1098, 496);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(108, 116);
            this.pnlMain.TabIndex = 1;
            // 
            // pnlStudent
            // 
            this.pnlStudent.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pnlStudent.Controls.Add(this.dgbStudents);
            this.pnlStudent.Controls.Add(this.grbStudent);
            this.pnlStudent.Controls.Add(this.lblStudents);
            this.pnlStudent.Location = new System.Drawing.Point(1039, 47);
            this.pnlStudent.Name = "pnlStudent";
            this.pnlStudent.Size = new System.Drawing.Size(182, 104);
            this.pnlStudent.TabIndex = 2;
            // 
            // grbStudent
            // 
            this.grbStudent.Controls.Add(this.btnAddStudent);
            this.grbStudent.Controls.Add(this.cboMajor);
            this.grbStudent.Controls.Add(this.cboCollege);
            this.grbStudent.Controls.Add(this.txtName);
            this.grbStudent.Controls.Add(this.lblCollege);
            this.grbStudent.Controls.Add(this.lblMajor);
            this.grbStudent.Controls.Add(this.lblName);
            this.grbStudent.Location = new System.Drawing.Point(17, 87);
            this.grbStudent.Name = "grbStudent";
            this.grbStudent.Size = new System.Drawing.Size(604, 120);
            this.grbStudent.TabIndex = 1;
            this.grbStudent.TabStop = false;
            this.grbStudent.Text = "Add Student";
            // 
            // btnAddStudent
            // 
            this.btnAddStudent.Location = new System.Drawing.Point(485, 69);
            this.btnAddStudent.Name = "btnAddStudent";
            this.btnAddStudent.Size = new System.Drawing.Size(104, 27);
            this.btnAddStudent.TabIndex = 8;
            this.btnAddStudent.Text = "Add Student";
            this.btnAddStudent.UseVisualStyleBackColor = true;
            this.btnAddStudent.Click += new System.EventHandler(this.btnAddStudent_Click);
            // 
            // cboMajor
            // 
            this.cboMajor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboMajor.FormattingEnabled = true;
            this.cboMajor.Location = new System.Drawing.Point(329, 20);
            this.cboMajor.Name = "cboMajor";
            this.cboMajor.Size = new System.Drawing.Size(260, 24);
            this.cboMajor.TabIndex = 7;
            // 
            // cboCollege
            // 
            this.cboCollege.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboCollege.FormattingEnabled = true;
            this.cboCollege.Location = new System.Drawing.Point(70, 69);
            this.cboCollege.Name = "cboCollege";
            this.cboCollege.Size = new System.Drawing.Size(387, 24);
            this.cboCollege.TabIndex = 6;
            this.cboCollege.SelectedIndexChanged += new System.EventHandler(this.cboCollege_SelectedIndexChanged);
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(70, 22);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(162, 22);
            this.txtName.TabIndex = 2;
            // 
            // lblCollege
            // 
            this.lblCollege.AutoSize = true;
            this.lblCollege.Location = new System.Drawing.Point(12, 74);
            this.lblCollege.Name = "lblCollege";
            this.lblCollege.Size = new System.Drawing.Size(55, 17);
            this.lblCollege.TabIndex = 4;
            this.lblCollege.Text = "College";
            // 
            // lblMajor
            // 
            this.lblMajor.AutoSize = true;
            this.lblMajor.Location = new System.Drawing.Point(268, 25);
            this.lblMajor.Name = "lblMajor";
            this.lblMajor.Size = new System.Drawing.Size(43, 17);
            this.lblMajor.TabIndex = 5;
            this.lblMajor.Text = "Major";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(12, 23);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(45, 17);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "Name";
            // 
            // lblStudents
            // 
            this.lblStudents.AutoSize = true;
            this.lblStudents.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStudents.Location = new System.Drawing.Point(12, 24);
            this.lblStudents.Name = "lblStudents";
            this.lblStudents.Size = new System.Drawing.Size(90, 25);
            this.lblStudents.TabIndex = 0;
            this.lblStudents.Text = "Students";
            // 
            // pnlGrades
            // 
            this.pnlGrades.BackColor = System.Drawing.Color.Orchid;
            this.pnlGrades.Controls.Add(this.dgbGrades);
            this.pnlGrades.Controls.Add(this.grbAddGrades);
            this.pnlGrades.Controls.Add(this.lblGrades);
            this.pnlGrades.Location = new System.Drawing.Point(12, 65);
            this.pnlGrades.Name = "pnlGrades";
            this.pnlGrades.Size = new System.Drawing.Size(640, 600);
            this.pnlGrades.TabIndex = 3;
            // 
            // lblGrades
            // 
            this.lblGrades.AutoSize = true;
            this.lblGrades.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGrades.Location = new System.Drawing.Point(13, 24);
            this.lblGrades.Name = "lblGrades";
            this.lblGrades.Size = new System.Drawing.Size(76, 25);
            this.lblGrades.TabIndex = 4;
            this.lblGrades.Text = "Grades";
            // 
            // dgbStudents
            // 
            this.dgbStudents.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgbStudents.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgbStudents.Location = new System.Drawing.Point(17, 237);
            this.dgbStudents.Name = "dgbStudents";
            this.dgbStudents.RowHeadersWidth = 51;
            this.dgbStudents.RowTemplate.Height = 24;
            this.dgbStudents.Size = new System.Drawing.Size(604, 346);
            this.dgbStudents.TabIndex = 2;
            // 
            // grbAddGrades
            // 
            this.grbAddGrades.Controls.Add(this.lblCourse);
            this.grbAddGrades.Controls.Add(this.lblTerm);
            this.grbAddGrades.Controls.Add(this.lblGrade);
            this.grbAddGrades.Controls.Add(this.lblStudent);
            this.grbAddGrades.Controls.Add(this.btnAddGrade);
            this.grbAddGrades.Controls.Add(this.cboTerm);
            this.grbAddGrades.Controls.Add(this.cboGrade);
            this.grbAddGrades.Controls.Add(this.cboCourse);
            this.grbAddGrades.Controls.Add(this.cboStudent);
            this.grbAddGrades.Location = new System.Drawing.Point(18, 94);
            this.grbAddGrades.Name = "grbAddGrades";
            this.grbAddGrades.Size = new System.Drawing.Size(601, 149);
            this.grbAddGrades.TabIndex = 5;
            this.grbAddGrades.TabStop = false;
            this.grbAddGrades.Text = "Add Grades";
            // 
            // cboStudent
            // 
            this.cboStudent.FormattingEnabled = true;
            this.cboStudent.Location = new System.Drawing.Point(76, 50);
            this.cboStudent.Name = "cboStudent";
            this.cboStudent.Size = new System.Drawing.Size(208, 24);
            this.cboStudent.TabIndex = 0;
            // 
            // cboTerm
            // 
            this.cboTerm.FormattingEnabled = true;
            this.cboTerm.Location = new System.Drawing.Point(356, 96);
            this.cboTerm.Name = "cboTerm";
            this.cboTerm.Size = new System.Drawing.Size(121, 24);
            this.cboTerm.TabIndex = 4;
            // 
            // cboGrade
            // 
            this.cboGrade.FormattingEnabled = true;
            this.cboGrade.Location = new System.Drawing.Point(356, 49);
            this.cboGrade.Name = "cboGrade";
            this.cboGrade.Size = new System.Drawing.Size(121, 24);
            this.cboGrade.TabIndex = 5;
            // 
            // cboCourse
            // 
            this.cboCourse.FormattingEnabled = true;
            this.cboCourse.Location = new System.Drawing.Point(76, 95);
            this.cboCourse.Name = "cboCourse";
            this.cboCourse.Size = new System.Drawing.Size(208, 24);
            this.cboCourse.TabIndex = 6;
            // 
            // btnAddGrade
            // 
            this.btnAddGrade.Location = new System.Drawing.Point(483, 50);
            this.btnAddGrade.Name = "btnAddGrade";
            this.btnAddGrade.Size = new System.Drawing.Size(95, 71);
            this.btnAddGrade.TabIndex = 7;
            this.btnAddGrade.Text = "Add Grade";
            this.btnAddGrade.UseVisualStyleBackColor = true;
            this.btnAddGrade.Click += new System.EventHandler(this.btnAddGrade_Click);
            // 
            // lblStudent
            // 
            this.lblStudent.AutoSize = true;
            this.lblStudent.Location = new System.Drawing.Point(11, 54);
            this.lblStudent.Name = "lblStudent";
            this.lblStudent.Size = new System.Drawing.Size(57, 17);
            this.lblStudent.TabIndex = 8;
            this.lblStudent.Text = "Student";
            // 
            // lblGrade
            // 
            this.lblGrade.AutoSize = true;
            this.lblGrade.Location = new System.Drawing.Point(297, 52);
            this.lblGrade.Name = "lblGrade";
            this.lblGrade.Size = new System.Drawing.Size(48, 17);
            this.lblGrade.TabIndex = 9;
            this.lblGrade.Text = "Grade";
            // 
            // lblTerm
            // 
            this.lblTerm.AutoSize = true;
            this.lblTerm.Location = new System.Drawing.Point(297, 99);
            this.lblTerm.Name = "lblTerm";
            this.lblTerm.Size = new System.Drawing.Size(41, 17);
            this.lblTerm.TabIndex = 10;
            this.lblTerm.Text = "Term";
            // 
            // lblCourse
            // 
            this.lblCourse.AutoSize = true;
            this.lblCourse.Location = new System.Drawing.Point(11, 99);
            this.lblCourse.Name = "lblCourse";
            this.lblCourse.Size = new System.Drawing.Size(53, 17);
            this.lblCourse.TabIndex = 11;
            this.lblCourse.Text = "Course";
            // 
            // dgbGrades
            // 
            this.dgbGrades.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgbGrades.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgbGrades.Location = new System.Drawing.Point(18, 249);
            this.dgbGrades.Name = "dgbGrades";
            this.dgbGrades.RowHeadersWidth = 51;
            this.dgbGrades.RowTemplate.Height = 24;
            this.dgbGrades.Size = new System.Drawing.Size(601, 332);
            this.dgbGrades.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1272, 680);
            this.Controls.Add(this.pnlGrades);
            this.Controls.Add(this.pnlStudent);
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.tbxMenuStrip);
            this.MainMenuStrip = this.tbxMenuStrip;
            this.Name = "Form1";
            this.Text = "Hog Country Students";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tbxMenuStrip.ResumeLayout(false);
            this.tbxMenuStrip.PerformLayout();
            this.pnlStudent.ResumeLayout(false);
            this.pnlStudent.PerformLayout();
            this.grbStudent.ResumeLayout(false);
            this.grbStudent.PerformLayout();
            this.pnlGrades.ResumeLayout(false);
            this.pnlGrades.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgbStudents)).EndInit();
            this.grbAddGrades.ResumeLayout(false);
            this.grbAddGrades.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgbGrades)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip tbxMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mainMenuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem studentsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gradesToolStripMenuItem;
        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.Panel pnlStudent;
        private System.Windows.Forms.Panel pnlGrades;
        private System.Windows.Forms.Label lblStudents;
        private System.Windows.Forms.Label lblGrades;
        private System.Windows.Forms.GroupBox grbStudent;
        private System.Windows.Forms.Button btnAddStudent;
        private System.Windows.Forms.ComboBox cboMajor;
        private System.Windows.Forms.ComboBox cboCollege;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblCollege;
        private System.Windows.Forms.Label lblMajor;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.DataGridView dgbStudents;
        private System.Windows.Forms.GroupBox grbAddGrades;
        private System.Windows.Forms.ComboBox cboTerm;
        private System.Windows.Forms.ComboBox cboGrade;
        private System.Windows.Forms.ComboBox cboCourse;
        private System.Windows.Forms.ComboBox cboStudent;
        private System.Windows.Forms.Button btnAddGrade;
        private System.Windows.Forms.DataGridView dgbGrades;
        private System.Windows.Forms.Label lblCourse;
        private System.Windows.Forms.Label lblTerm;
        private System.Windows.Forms.Label lblGrade;
        private System.Windows.Forms.Label lblStudent;
    }
}

